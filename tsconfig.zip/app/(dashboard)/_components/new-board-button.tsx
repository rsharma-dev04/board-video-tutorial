"use client";

import { toast } from "sonner";
import { Plus } from "lucide-react";
import { cn } from "@/lib/utils";

import { api } from "@/convex/_generated/api";
import { useApiMutation } from "@/app/hooks/use-api-mutation";
import { useRouter } from "next/navigation";


interface NewBoardButtonProps {
  orgId: string;
  disabled?: boolean;
}

export const NewBoardButton = ({
  orgId, 
  disabled,
}: NewBoardButtonProps) => {
  const router = useRouter();
  const {mutate, pending} = useApiMutation(api.board.create);

  const onClick = () => {
    mutate({
        orgId,
        title: "Untitled"
    })
    .then ((id) => {
        toast.success("Board created");
        router.push(`/board/${id}`);

    })
    .catch(() => toast.error("Failed to create board"));
 }

  return (
    <button
      disabled={pending || disabled}
      onClick={onClick}
      className={cn(
        "col-span-1 aspect-[100/127] bg-blue-600 rounded-lg hover:bg-blue-800 flex flex-col items-center justify-center p-6 text-white transition",
        (pending || disabled) && "opacity-75 hover:bg-blue-600 cursor-not-allowed"
      )}
    >
      <div />
      <Plus className="h-12 w-12 stroke-1" />
      <p className="text-sm font-light">
        New board
      </p>
    </button>
  );
};